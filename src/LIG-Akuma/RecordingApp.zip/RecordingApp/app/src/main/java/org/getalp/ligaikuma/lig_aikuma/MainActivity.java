/*
	Copyright (C) 2013, The Aikuma Project
	AUTHORS: Oliver Adams and Florian Hanke
*/
package org.getalp.ligaikuma.lig_aikuma;

import android.Manifest;
import android.app.ActionBar;
import android.app.ListActivity;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;

import org.getalp.ligaikuma.lig_aikuma.lig_aikuma.BuildConfig;
import org.getalp.ligaikuma.lig_aikuma.lig_aikuma.R;
import org.getalp.ligaikuma.lig_aikuma.model.Recording;
import org.getalp.ligaikuma.lig_aikuma.ui.sensors.LocationDetector;

import java.io.IOException;
import java.util.List;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * The primary activity that lists existing recordings and allows you to select
 * them for listening and subsequent respeaking.
 *
 * @author Oliver Adams	<oliver.adams@gmail.com>
 * @author Florian Hanke	<florian.hanke@gmail.com>
 */
public class MainActivity extends ListActivity implements EasyPermissions.PermissionCallbacks {

    private static final String TAG = "MainActivity";

    public static LocationDetector locationDetector;

    // Helps us store how far down the list we are when MainActivity gets
    // stopped.
    private Parcelable listViewState;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        startProcessing();
    }



    public void startProcessing() {
        // Start gathering location data
        MainActivity.locationDetector = new LocationDetector(this);

        // Create an index file when app starts
        try {
            Recording.indexAll();
        } catch (IOException e) {
            if (BuildConfig.DEBUG) Log.e(TAG, e.getMessage());
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        listViewState = getListView().onSaveInstanceState();
        MainActivity.locationDetector.stop();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (BuildConfig.DEBUG) Log.i(TAG, "num: " + Recording.readAll().size());

        if (listViewState != null)
            getListView().onRestoreInstanceState(listViewState);

        MainActivity.locationDetector.start();
    }

    @Override
    protected void onStart() {
        super.onStart();
        showProgressStatus(View.GONE);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        MainActivity.locationDetector.stop();
    }

    /**
     * Show the status of cloud-background thread
     *
     * @param visibility Visibility of the progress bar View
     */
    public void showProgressStatus(int visibility) {
        findViewById(R.id.cloudProgress).setVisibility(visibility);
    }

    @AfterPermissionGranted(100)
    public void getPermissions() {
        String[] perms = {
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.READ_EXTERNAL_STORAGE
        };
		Toast.makeText(this, "Let's get permissions", Toast.LENGTH_SHORT).show();
        if (EasyPermissions.hasPermissions(this, perms)) {
            Toast.makeText(this, "Opening camera", Toast.LENGTH_SHORT).show();
        } else {
            EasyPermissions.requestPermissions(this, "We need permissions because this and that",
                    100, perms);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        startProcessing();
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            new AppSettingsDialog.Builder(this).build().show();
        }
    }
}
